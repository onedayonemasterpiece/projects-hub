# Integration contract

This document covers transport/package integration. The mandatory product
architecture for prompt layering, progressive capability disclosure, session
continuity, modality-aware resource accounting, logging and acceptance lives in
[Live agent architecture and operating standard](live-agent-architecture.md).
A new or materially changed consumer MUST follow both documents.

## Pin and import

The first consumer uses a release tarball in its private `vendor/` directory.
Build it with `npm pack` from a clean, committed framework checkout. Record its
release version and archive SHA-256 in the consumer's `liveFramework` package metadata,
use a `file:vendor/live-interaction-<version>.tgz` dependency, and commit the npm
lockfile (SHA-512 integrity). CI verifies version metadata, archive digest, lockfile
and installed/generated assets. This is an immutable distribution artifact, not
an editable source fork. Update it from the next versioned framework release; keep the source commit only in release receipts.
This also works in container builds without granting a cross-repository key to CI.
Do not distribute a private package inside a public product without authorization.

The framework repository is public. Consumers preferring Git version resolution may use this form:

Node: `@onedayonemasterpiece/live-interaction` dependency set to
`git+https://github.com/onedayonemasterpiece/live-interaction.git#semver:^0.1.0`.
Commit the lockfile. Build browser assets with
`installBrowserAssets(destination)` from the package `/assets` export; include
these generated modules in the application's content hash/cache manifest. Never
edit or commit generated copies. Import `createLiveClient` from the generated
`client.js`; server imports `createLiveSessionHost` from the `/node` export.

Python: install `live-interaction @ git+https://github.com/onedayonemasterpiece/live-interaction.git@v0.1.2`.
Use `live_interaction.provider.run(load_key=server_credential_resolver)` for the
worker entrypoint. Default resolver reads only `LIVE_API_KEY`. Node packages
include the same Python module, so a Node consumer need not perform a separate
pip install of the project (websockets must already be installed).

`run(reader=asyncio.StreamReader(...), on_event=callback, load_key=resolver)` is
also available for a Python host. Feed bounded NDJSON commands to the reader;
callbacks receive events. Product endpoints and tool authorization belong in
the host. Python applications should reuse this transport; they do not need the
Wonderful Lections presentation service or Node to connect to Google.

For in-process Python products, `live_interaction.session_host.LiveSessionHost` is the
matching generic host. Construct it with an `adapter_factory` and a server-owned
`key_resolver(resource_id, actor)`. The adapter implements `initialize(...)` and
`execute_tool(session, call)`; optional `input`, `on_started`, `on_resumed`, and
`on_stopped` hooks mirror the Node host semantics. Optional `on_event(session, event)` observes\nprovider events before host projection, so a product can keep bounded conversation context\nwithout moving domain state into the provider. The host binds every session to
resource+actor, bounds provider input to 768 KiB, caps audio chunks at 16k base64
characters, paginates a 320-event ring, serializes tools, deduplicates successful
provider call IDs, honors cancellation before execution, and never replays a mutation.
Applications still authenticate every HTTP route before calling the host.

`configuration.manual_activity_detection=true` creates a session with provider automatic
activity detection disabled. In that mode the host accepts `activity_start`, one or more
`audio_base64` chunks, then `activity_end`; `audio_stream_end` is rejected. This is for
deliberate buffered turns, not normal realtime reconnect replay. Provider transcript events
remain complete for the trusted adapter `on_event` observer; only the polling/UI ring projects
transcript text to a bounded 2000-character preview. A durable observer must persist or
durably enqueue the trusted event before returning.

## Browser API

`createLiveClient({request?, onEvent, onState, onNotice, onTiming, onWait,
voiceControl?})` returns `start`, `stop`, `input` and read-only `sessionId`,
`starting`, `generation`, `playingCount`.

`start({url,body,authorize,takeMicrophoneHandoff?,microphone?,captureDuringStart?})`: same-origin authenticated collection URL, application
start arguments (model/context IDs/history, never a key), async authorization. A
microphone handoff reuses the existing MediaStream and may seed buffered PCM captured
while the server/provider session was starting; it must not open a second microphone.
For a manual push-to-toggle start with no already-open microphone,
`captureDuringStart:true` opens local capture immediately after local authorization,
buffers up to the existing 20s startup bound while the session POST is pending,
then reuses that same MediaStream and buffered PCM when Live becomes ready.
Default HTTP protocol: POST collection -> `{session_id,model,...app metadata}`;
POST `/:id/input` -> `{ok:true}`; GET `/:id/events?after=N` ->
`{events,cursor,has_more,gap,closed}`; POST `/:id/stop` -> `{ok:true}`.
The host authenticates **every** route before dispatch, including event polling.
A custom `request` must honor abort signals and the same bounded timeouts.

`stop({reason,keepalive,preservePlayback})` synchronously stops capture/tracks,
invalidates the epoch, clears pending speech, aborts requests and calls
`onState('off')`. Remote cleanup has its own 2.5s bound. Preserve received playback
only on provider closure/transport failure, never for a user's explicit Stop.
`input({text})` starts a turn; `input({...product context})` is adapter-specific.

`onEvent(event,generation)` must not block playback with a long domain refresh.
Before applying asynchronous UI results, compare the generation to the current
client generation. Tools and mutation busy/readback indicators remain app policy.
`onState`: starting, started, listening, answering, reconnecting, off,
microphone_unavailable, connection_error, start_error.
`onNotice`: voice_stop_confirmation_requested, voice_stop_cancelled,
voice_stop_expired, event_gap, transport_error, microphone_error,
connection_error, start_error; second argument may be an Error.
`onTiming` contains bounded numeric diagnostics, not speech/secret payloads.
`onWait(null | {elapsed_ms,stage,can_restart})` stays hidden below 15 seconds;
show mm:ss, a gentle pulse honoring reduced motion, and an immediate Stop.
Stage is transport until worker-send/ASR evidence, then provider; outstanding tool calls use action so a slow application is not blamed on Google. Extended intermediate turnComplete does not complete an outstanding wait. At 120 seconds,
offer explicit Stop+Start without replaying the old command. Never auto-restart
or automatically retry a mutation. Already accepted writes may still finish;
refresh authoritative product state after reconnect.

Russian voice Stop uses two separate utterances, a 30s confirmation window and
900ms fragment debounce. Supply another `voiceControl` parser or `false` for a
different language/policy. The **application system instruction must also ask
for confirmation aloud** and must not claim the microphone is off before it is.
A button Stop always bypasses confirmation. No generic edit/call permissions are
introduced by voice control.

## Node adapter

`createLiveSessionHost({adapterFactory,createWorker,ErrorClass?,models?,
readyTimeoutMs?,reconfigureTimeoutMs?,maxSessions?})` returns
start/input/events/stop/stopAll/size.
The public host args are `resourceId`, `actor`, and, after setup, `sessionId`.
Start also takes model/history and adapter-specific arguments. Authenticate before
calling the host; it additionally binds subject+tenant+resource to each session.
Do not expose the internal actor-omitting stopAll path over HTTP.

`adapterFactory({emit,write,measure,timing})` returns:

- `initialize({resourceId,actor,model,...args})` validates access and returns
  `{state,capability?,context,configuration,response}`. No mutation during initialization.
- `executeTool(session,{id,name,args})` authorizes each ordinary tool, validates arguments,
  and runs the product's normal prepare/apply/readback semantics.
- Optional `resolveCapability(session,call)` (Python: `resolve_capability`) is a
  side-effect-free router resolver. Return null for an ordinary tool or
  `{capability,configuration,context?,continuation?,response?}` for a capability
  transition. `continuation` is a bounded application-owned summary of the
  already pending intent; when omitted, hosts may use the router call's bounded
  `intent` argument. It is context, not permission.
  Capability IDs are bounded identifiers; a transition bundle contains at most
  nine functions and at most 256 KiB serialized configuration.
- Optional `input`, `onStarted`, `onResumed`, `onStopped` for product context and
  latest-only frame updates. Clear timers on Stop, resend latest image on resume.

`configuration` is server-owned: `system_instruction`, `context_instruction`,
`functions` (Gemini declarations), `voice` (default Aoede), `search_enabled`
(default false). Never accept arbitrary declarations/instructions from a browser.
The host caches successful tool results by provider call ID and serializes tools;
application idempotency must still survive process/session restarts. If
`resolveCapability` selects a transition, that router call must be the only tool
call in its provider batch. The host sends one bounded `reconfigure` worker
command containing the server-owned configuration, a router acknowledgement and
the bounded continuation intent. For Gemini the worker sends that acknowledgement
on the old connection first, waits for a **fresh post-response** resumable handle,
then resumes the same model/key/session with the new bundle. If Gemini does not issue a fresh checkpoint within the bounded wait, the worker discards the old handle, opens a new connection with the same model/key, restores bounded dialogue history, and delivers the one accepted continuation. After
`capability_ready` the host updates active capability/configuration state but
must not send a duplicate FunctionResponse. Transition failure is emitted as
structured transition/tool metadata; it is never silently converted into a
successful fresh conversation.

`createWorker({model,actor,resourceId})` returns a child with stdin/stdout/stderr
and kill(). Spawn the shared Python provider or a **thin credential adapter**.
Only the server chooses an approved credential binding; do not send it through
setup JSON, browser APIs, transcripts or receipts. Whitelist the child environment.
Different product instances can select different server-side keys. Resolve once
per session; resumption keeps the same key/model. Missing credentials fail closed;
quota failure never triggers key hopping. No shared global default credential pool.

## Worker wire and limits

Start: `{type:'start',model,context,configuration,history}`. Inputs: audio
(base64 PCM16, 16kHz mono), audio_stream_end, text, snapshot (JPEG+context),
tool_response, `reconfigure`, stop. `reconfigure` carries a server-owned
transition ID, capability ID, full bounded configuration, optional context,
bounded `continuation`, and the exact router FunctionResponse acknowledgement.
For Gemini the worker writes that acknowledgement on the current WebSocket,
invalidates the old resumption token, waits for a fresh resumable handle issued
after the acknowledgement, closes only that WebSocket intentionally, resumes
the same model/session with the new configuration, emits `capability_ready`,
and sends one bounded `LIVE_CONTINUATION` application turn. Inputs queued
before the handoff completes are dropped rather than replayed. Writes include
numeric `queued_at` for delay measurement.
Snapshot uses video input only, never an implicit user text turn. Product images
must be current and bounded before transport. Do not replay captured audio on
recovery. Tools are cancelled only before starting; accepted writes require
normal domain reconciliation.

Current measured defaults: 256ms batch; <=11000 PCM bytes / <=16000 base64
characters; 1.5s buffered PCM and 2.5s item-age steady-state guards; 2.5s non-audio input request bound; 10s absolute audio/audio_stream_end HTTP ceiling; one in-flight sender;
250ms preroll; conservative RMS gate; 2s quiet tail. An intentional startup
microphone handoff may seed at most 20s of PCM and temporarily uses a separate
bounded catch-up ceiling (seed + the ordinary 1.5s queue). Once the backlog is
back within the ordinary watermark, queued ages are rebased once and the strict
1.5s / 2.5s steady-state guards resume. The longer 10s audio HTTP ceiling does not extend that queue/age budget: a continuing stalled microphone stream still fails through the sender first. Silence is suppressed after
the tail. PCM is required by this provider transport; AAC/OGG would need a measured
server decoder and new acceptance, not just a MIME rename. Poll 160ms, drain
has_more immediately, report gaps, and play every received audio buffer before
considering a provider closure finished. Model mic energy alone is not barge-in.

## Release gate and ownership

Core changes go here and run Node/Python tests. Capability routing, configuration
digests, provider reconfiguration and audit behaviour are shared framework concerns;
do not reimplement them independently in a consumer once the corresponding released
framework primitive exists.

A consumer selects a versioned
release and verifies generated assets match the installed package. Existing
Wonderful Lections CI also rejects known duplicate transport implementations.
Agent instructions/skill route new integrations here, but no skill can prevent
all future deliberate divergence; code review and versioned dependency checks enforce it.

A new adapter/release requires real browser voice acceptance: 10 turns, authorized
product actions, navigation/context changes, immediate Stop/no later audio POST,
restart, full playback and voice confirmation. For connection/recovery changes,
include long session and genuine provider resumption receipts. Keep provider
failures visible and distinguish fixtures from real acceptance.

Wonderful Lections Show should have a separate **read-only cohost tool adapter**,
not reuse Review's mutation permissions by default. Street-story / idea-hub need
their own context, authorization and UI; none is implemented by this extraction.

## Updating a consumer by version

For the initial npm archive distribution, use the source repository helper:

```sh
node scripts/update-consumer.mjs /path/to/product 0.1.0 /path/to/managed/artifacts
# Or resolve the current stable release once:
node scripts/update-consumer.mjs /path/to/product latest /path/to/managed/artifacts
```

It downloads the versioned public release, checks package identity, updates the
versioned archive/manifest and lockfile. Then run npm ci/build and acceptance.
`latest` is resolved during this explicit update; it never changes the code of
an already running Live session. Keep previous package archives only if needed
for your source history/release policy. The helper neither commits nor deploys.

## Shared resource guard in 0.1.3

A consumer that reserves Live capacity through a shared controller passes its
lease to the provider as resource_guard. The transport checks the lease before
opening or resuming a provider connection and before/after provider receives.
It calls before_send(payload) before setup and every outbound provider message,
then rechecks the lease before bytes are written.

The key is resolved once from resource_guard.key() and remains pinned through
session resumption. An exception marked resource_failure is terminal for the
provider session: it is propagated to the resource controller and cannot cause
reconnect, Search capability downgrade, or key rotation.

The parameter is optional only for compatibility with consumers that have not
yet migrated. New or changed managed consumers must supply the shared guard.

## Future provider research

The 0.1.x provider transport is Gemini-specific. Potential alternatives are kept
in [the Live provider research backlog](provider-research-backlog.md), including
Qwen Audio/Omni Realtime, StepAudio, GLM-Realtime, SeedRealtime, OpenAI
Realtime/GPT-Live, Grok Voice, Nova Sonic, Hume EVI and self-hosted research
options such as MiniCPM-o and PersonaPlex.

This list is intentionally **not** a fallback chain. A new provider needs a thin
adapter plus provider-specific real acceptance. Do not switch providers inside a
running/recovering session merely because Gemini is slow, unavailable or out of
quota.